#pragma once
#include <string>

namespace My {

	std::string ReadFile(std::string path);

}
